/*
 * Part1.c
 *
 * Created: 2023-01-20 11:28:12
 *  Author: leorb
 */ 

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <stdint.h>

#include "IncFile2.h"

volatile char LCD_Data[LCD_REGISTER_COUNT];

const unsigned int LCD_character_table[] PROGMEM =
{
	0x5559,     // '0'
	0x0118,     // '1'
	0x1e11,     // '2
	0x1b11,     // '3
	0x0b50,     // '4
	0x1b41,     // '5
	0x1f41,     // '6
	0x0111,     // '7
	0x1f51,     // '8
	0x1b51,     // '9'
	0x0f51,     // 'A' (+ 'a')
	0x3991,     // 'B' (+ 'b')
	0x1441,     // 'C' (+ 'c')
	0x3191,     // 'D' (+ 'd')
	0x1e41,     // 'E' (+ 'e')
	0x0e41,     // 'F' (+ 'f')
	0x1d41,     // 'G' (+ 'g')
	0x0f50,     // 'H' (+ 'h')
	0x2080,     // 'I' (+ 'i')
	0x1510,     // 'J' (+ 'j')
	0x8648,     // 'K' (+ 'k')
	0x1440,     // 'L' (+ 'l')
	0x0578,     // 'M' (+ 'm')
	0x8570,     // 'N' (+ 'n')
	0x1551,     // 'O' (+ 'o')
	0x0e51,     // 'P' (+ 'p')
	0x9551,     // 'Q' (+ 'q')
	0x8e51,     // 'R' (+ 'r')
	0x9021,     // 'S' (+ 's')
	0x2081,     // 'T' (+ 't')
	0x1550,     // 'U' (+ 'u')
	0x4448,     // 'V' (+ 'v')
	0xc550,     // 'W' (+ 'w')
	0xc028,     // 'X' (+ 'x')
	0x2028,     // 'Y' (+ 'y')
	0x5009,     // 'Z' (+ 'z')

};
void LCD_Init(void)
{

	LCD_CONTRAST_LEVEL(LCD_INITIAL_CONTRAST);    //Set the LCD contrast level

	// Select asynchronous clock source, enable all COM pins and enable all
	// segment pins.
	LCDCRB = (1<<LCDCS) | (3<<LCDMUX0) | (7<<LCDPM0);

	// Set LCD prescaler to give a framerate of 32,0 Hz
	LCDFRR = (0<<LCDPS0) | (7<<LCDCD0);

	LCDCRA = (1<<LCDEN) | (1<<LCDAB);           // Enable LCD and set low power waveform

	//Enable LCD start of frame interrupt
	LCDCRA |= (1<<LCDIE);

	//updated 2006-10-10, setting LCD drive time to 1150us in FW rev 07,
	//instead of previous 300us in FW rev 06. Due to some variations on the LCD
	//glass provided to the AVR Butterfly production.
	LCDCCR |= (1<<LCDDC2) | (1<<LCDDC1) | (1<<LCDDC0);

}




void writeChar(char ch, uint8_t pos)
{
	if (!(ch >= 48 && ch<=57))
    {
		return;
    }
    typedef struct
	{    
        uint8_t nibbles[4];
        uint16_t fontValue;
        volatile uint8_t *ptr; 
	} 
	regz;
    regz registers;
    
    registers.fontValue = LCD_character_table[9-(57-ch)];
	registers.ptr = (uint8_t*) 0xEC + pos/2;
	
    for(uint8_t i=0; i< 4; i++)
	{    
        *(registers.nibbles+i) = registers.fontValue & 0xf, registers.fontValue >>=4;
		
        if(!(pos%2)) 
		{ 
			*registers.ptr &= ~(0xf), *registers.ptr |= *(registers.nibbles+i);
		}
        else
		{ 
			*registers.ptr &= ~(0xf0), *registers.ptr |= (*(registers.nibbles+i) << 4); 
		}
        registers.ptr+=5;
    }    
} // struct
/*
void writeChar(char ch, int pos)
{		
	int out;
	if(ch == "A"){
		out = 0x0F51; 
	}
	if(ch == "B"){
		out = 0x0F51;
	}
	if(ch == "C"){
		out = 0x0F51;
	}
	if(ch == "D"){
		out = 0x3191;
	}
	if(ch == "E"){
		out = 0x1e41;
	}
	if(ch == "F"){
		out = 0x0e41;
	}
	
	if(pos == 0){
		LCDDR0 = 5;	
		LCDDR5 = 5;
		LCDDR10 = 5;
		LCDDR15 = 9;
	}
	if(pos == 1){
		LCDDR1 = 9;
		LCDDR6 = 4;
		LCDDR11 = 5;
		LCDDR16 = 9;
	}
	if(pos == 2){
		LCDDR2 = 1;
		LCDDR7 = 4;
		LCDDR12 = 4;
		LCDDR17 = 1;
	}
	if(pos == 3){
		LCDDR0 = 3;
		LCDDR5 = 1;
		LCDDR10 =9;
		LCDDR15 =1;
	}
	if(pos == 4){
		LCDDR0 = 1;
		LCDDR5 = 14;
		LCDDR10 = 4;
		LCDDR15 = 1;
	}
	//if(pos == 5){
	//	LCDDR2 = out;
	//}

}
*/