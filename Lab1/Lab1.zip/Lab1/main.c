/*
 * Lab1.c
 *
 * Created: 2023-01-19 22:34:55
 * Author : leorb
 */ 

#include <avr/io.h>
#include <util/delay.h>
#include <string.h>

//#include "LCD_driver.c"

#define _PROTECTED_WRITE(register, value);




//DDRA=255; // Set the output pins /DDRA=0b11111111 This is port A on the chip
//PORTA=0b0000000; // give 0v from all porta pins


void LCD_Init(void)
{

	LCDCRB = (1<<LCDCS) | (1<<LCDMUX1)| (1<<LCDMUX0) |(1<<LCDPM2) | (1<<LCDPM1) | (1<<LCDPM0);

	LCDFRR = (0<<LCDPS2) | (1<<LCDCD2) | (1<<LCDCD1) | (1<<LCDCD0);
	
	LCDCCR = (1<<LCDCC3) | (1<<LCDCC2) | (1<<LCDCC1) | (1<<LCDCC0);
	
	LCDCRA =  (1<<LCDEN); // LCDCRA |= 0x80 ----> ENABLE DISPLAY!

	
	// SCC = 0
	LCDDR0 =0x8;
	LCDDR5=0x1;
	LCDDR10=0x1;
	LCDDR15=0x0;

	LCDDR1=0x1;
	LCDDR6=0x1;
	LCDDR11=0xe;
	LCDDR16=0x1;
}

void USART1_init(void)
{	
		_PROTECTED_WRITE(CLKPR, 0x80);
		_PROTECTED_WRITE(CLKPR, 0x00);
}


int main(void)
{
	USART1_init();
	//LCD_Init();
	while(1){
		
	
	int index = 0;
	char arr[5] = "12345";
	while(index <= 4)
	{
		char ch = arr[index];
		writeChar(ch, index);
		index++;
		_delay_ms(1000); //delay 0.5 sec
	}
	
	}
    
	return 0;
}

